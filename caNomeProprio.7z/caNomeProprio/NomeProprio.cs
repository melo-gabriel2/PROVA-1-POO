﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caProva1
{
    internal class NomeProprio
    {
        private string nome_completo;
        private string nome_paper;

        public NomeProprio(string nome_completo) 
        { 
            this.nome_completo = nome_completo;
        }

        public string Nome_completo { get => nome_completo; set => nome_completo = value; }
        public string Nome_paper { get => nome_paper; set => nome_paper = value; }

        public void ImprimeNomePaper()
        {
            string[] separanome = this.nome_completo.Split(' ');
            string primeironome = separanome[0];
            string ultimonome = separanome[(separanome.Length)-1];
            string nomedomeio;
            if (separanome.Length > 2)
            {
                nomedomeio = separanome[1] ;
                nomedomeio = nomedomeio[0] + ".";
            }
            else
            {
                nomedomeio = "";
            }
            nome_paper = ultimonome + "," + " "+ primeironome + " " + nomedomeio;
            Console.WriteLine(nome_paper);
        }
    }
}
