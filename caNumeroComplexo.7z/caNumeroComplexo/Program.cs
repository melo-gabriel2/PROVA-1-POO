﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace caNumeroComplexo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NumComplexo z1 = new NumComplexo(1, 1);
            NumComplexo z2 = new NumComplexo(3, -1);

            NumComplexo zsoma = z1.soma(z2);
            zsoma.ImprimeFormaPolar();
            NumComplexo zproduto = z1.vezes(z2);
            zproduto.ImprimeFormaPolar();
            Console.ReadLine();
        }
    }
}
