﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace caNumeroComplexo
{
    internal class NumComplexo
    {
        private double Re;
        private double Im;
        
        public NumComplexo()
        {
            Re = 0;
            Im = 0;
        }

        public NumComplexo(double _Re, double _Im)
        {
            Re = _Re;
            Im = _Im;
        }

        public double Re1 { get => Re; set => Re = value; }
        public double Im1 { get => Im; set => Im = value; }

        public NumComplexo soma(NumComplexo z)
        {
            NumComplexo zsoma = new NumComplexo(this.Re + z.Re, this.Im + z.Im);
            return zsoma;
        }

        public NumComplexo vezes(NumComplexo z)
        {
            NumComplexo zvezes = new NumComplexo();
            double produtomodulo = this.Modulo() * z.Modulo();
            double somagraus = this.Argumento() + z.Argumento();
            zvezes.Re = produtomodulo * Math.Cos(somagraus);
            zvezes.Im = produtomodulo * Math.Sin(somagraus);
            return zvezes;
        }

        public double Modulo()
        {
            return (Math.Pow(Math.Pow(this.Re, 2)+ Math.Pow(this.Im, 2), 1/2));
        }

        public double Argumento()
        {
            double angulorad = Math.Atan(Im / Re);
            double angulograus = angulorad*(180/Math.PI);
            return angulograus;
        }
        
        public void ImprimeFormaPolar()
        {
            Console.WriteLine("Módulo: " + this.Modulo());
            Console.WriteLine("Graus: " + this.Argumento());
        }
    }
}
